package com.ibm.service.controler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;

import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping ( value = "/service" )
public class ServiceRestController
{
    
    @Autowired
    private EurekaClient eurekaClient;
    
    @Autowired
    private RestTemplate restTemplate;
    
	private static final Logger logger = LoggerFactory.getLogger( ServiceRestController.class );
	
	// in earlier versions of the Spring cloud starter for Eureka, a RestTemplate bean was created for you, but this is no longer true. 
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
	
    @RequestMapping ( value = "/", method = RequestMethod.GET )
    public String serviceInstancesByApplicationName (@RequestParam("name") String name)
    {
        logger.info( "inside GET /service1" );

        // Normally we would have a separate service, but for this self-contained example we'll simply call our application via REST
        // final String service2greeting = this.service2FeignClient.hello();
        Application application = eurekaClient.getApplication("Hello-service2");
        InstanceInfo instanceInfo = application.getInstances().get(0);
        String url = "http://" + instanceInfo.getIPAddr() + ":" + instanceInfo.getPort() + "/" + "service2/";
        
        // as we are using zuul gateway we dont need to lookup for microservice IP and port, it will fetched by zuul from eureka server
        String microserviceName = "hello-service2/";
        url = "http://localhost:8080/services/"+microserviceName+ "service2/";
        System.out.println("URL" + url);
//        	throw new Exception("Error after getting instance of Service2");
        String outputService2 = restTemplate.getForObject(url, String.class);
        return " from service1: Hello "+name+ " : Service2 : "+ outputService2;
    }
}