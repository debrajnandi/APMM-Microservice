package com.ibm.service.controler;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@FeignClient( "http://Test-Microservice" )
public interface Service2FeignClient
{
    @RequestMapping ( value = "/service2/", method = RequestMethod.GET )
    String hello ();
}
