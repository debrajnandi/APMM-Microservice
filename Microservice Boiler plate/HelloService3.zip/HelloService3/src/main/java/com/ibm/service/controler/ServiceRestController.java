package com.ibm.service.controler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping ( value = "/service2" )
public class ServiceRestController
{
    private static final Logger logger = LoggerFactory.getLogger( ServiceRestController.class );

    @RequestMapping ( value = "/", method = RequestMethod.GET )
    public String hello ()
    {
        logger.info( "inside GET /service2" );
        return "Completed service2 execution.";
    }
}